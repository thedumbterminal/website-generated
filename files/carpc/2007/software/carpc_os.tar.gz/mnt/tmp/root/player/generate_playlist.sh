#!/bin/bash
#finds all the mp3 files
LOC=/mnt/auto
DEVPREFIX=usb
MAXDEVICES=4
COUNT=0
PLAYLIST=/tmp/music_files.txt
PLAYER=/usr/bin/mpg321
echo -n "Searching for MP3s..."
echo -n > $PLAYLIST
while [ "$COUNT" -lt "$MAXDEVICES" ]; do
	DISK=$LOC/$DEVPREFIX$COUNT
	if [ -r "$DISK" ]; then
		find $DISK -type f -iname "*.mp3" >> $PLAYLIST
	fi
	let COUNT=$COUNT+1
done
echo "done"
echo "Starting player...\n"
ls -al $PLAYLIST
$PLAYER --shuffle --list $PLAYLIST &
